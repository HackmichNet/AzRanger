function showMain(view){
    if(view == "M365-Mainview"){
        $("#M365-Mainview").show();
        $("#Azure-Mainview").hide();
        $("#Details-Mainview").hide();

        $("#ShowM365Button").attr("class","nav-link px-2 text-secondary");
        $("#ShowAzureButton").attr("class","nav-link px-2 text-white");
        $("#ShowDetailsButton").attr("class","nav-link px-2 text-white");
    }
    if(view == "Azure-Mainview"){
        $("#M365-Mainview").hide();
        $("#Azure-Mainview").show();
        $("#Details-Mainview").hide();
        
        $("#ShowM365Button").attr("class","nav-link px-2 text-white");
        $("#ShowAzureButton").attr("class","nav-link px-2 text-secondary");
        $("#ShowDetailsButton").attr("class","nav-link px-2 text-white");
    }
    if(view == "Details-Mainview"){
        $("#M365-Mainview").hide();
        $("#Azure-Mainview").hide();
        $("#Details-Mainview").show();

        $("#ShowM365Button").attr("class","nav-link px-2 text-white");
        $("#ShowAzureButton").attr("class","nav-link px-2 text-white");
        $("#ShowDetailsButton").attr("class","nav-link px-2 text-secondary");
    }
};