function getColor(value, max_value){
  //value from 0 to 1
  var hue=((1-value/max_value)*120).toString(10);
  return ["hsl(",hue,",100%,50%)"].join("");
}

function createAccordionItem(element, accordionSection){
    //console.log(element.ShortName);
    var temp = $.trim($('#RuleResultTemplate').html());
    var x = temp.replace(/{{ShortDescription}}/ig, element.ShortDescription);
    var criticality;
    if(element.RiskScore == 0){
      criticality = "[None]"
    }
    if(element.RiskScore > 0 & element.RiskScore <= 3){
      criticality = "[Low]"
    }
    if(element.RiskScore > 3 & element.RiskScore <= 6){
      criticality = "[Medium]"
    }
    if(element.RiskScore > 6 & element.RiskScore <= 9){
      criticality = "[High]"
    }
    if(element.RiskScore == 10){
      criticality = "[Ciritcal]"
    }
    x = x.replace(/{{Criticality}}/ig, criticality);

    if(element.LongDescription != null){
      var insertData = '<div class="row"><div class="col"><strong>Description: </strong>' + element.LongDescription + '</div></div>';
      x = x.replace(/{{LongDescription}}/ig, insertData);
    }else{
      x = x.replace(/{{LongDescription}}/ig, "");
    }

    if(element.Risk != null){
      var insertData = '<div class="row"><div class="col"><strong>Risk: </strong>' + element.Risk + '</div></div>';
      x = x.replace(/{{Risk}}/ig, insertData);
    }else{
      x = x.replace(/{{Risk}}/ig, "");
    }

    if(element.Reason != null){
      var insertData = '<div class="row"><div class="col"><strong>Reason: </strong></br>' + element.Reason + '</div></div><br>';
      x = x.replace(/{{Reason}}/ig, insertData);
    }else{
      x = x.replace(/{{Reason}}/ig, "");
    }

    
    if(element.Solution != null){
      var insertData = '<div class="row"><div class="col"><strong>Solution: </strong>' + element.Solution + '</div></div>';
      x = x.replace(/{{Solution}}/ig, insertData);
    }else{
      x = x.replace(/{{Solution}}/ig, "");
    }

    if(element.PortalUrl != null){
      var insertData = '<div class="row"><div class="col">Portal Url: <a href="' + element.PortalUrl + '" target="blank">' + element.PortalUrl + '</a></div></div><br>';
      x = x.replace(/{{PortalUrl}}/ig, insertData);
    }else{
      x = x.replace(/{{PortalUrl}}/ig, "");
    }

    if(element.ReferenceLink != null){
      var insertData = '<div class="row"><div class="col">Reference Link: <a href="' + element.ReferenceLink + '" target="blank">' + element.ReferenceLink  + '</a></div></div><br>';
      x = x.replace(/{{ReferenceLink}}/ig, insertData);
    }else{
      x = x.replace(/{{ReferenceLink}}/ig, "");
    }

    if(element.CISDocument != null){
      var CISInfos = element.CISDocument + " " + element.Section + " Level: " + element.Level + " Version: " + element.Version;
      
      var insertData = '<div class="row"><div class="col">CIS Reference: ' + CISInfos + '</div></div>';
      x = x.replace(/{{CISInfos}}/ig, insertData);
    }else{
      x = x.replace(/{{CISInfos}}/ig, "");
    }

    if(element.AffectedItems != null){

      insertData = '<div class="accordion" id="accordion_affectedItem_' + element.ShortName +'">'+
                      '<div class="accordion-item">' +
                        '<h2 class="accordion-header">' +
                          '<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse_affectedItem_' + element.ShortName + '" aria-expanded="true" aria-controls="collapse_affectedItem_' + element.ShortName + '">' +
                          'Expand Affected Objects</button>' +
                        '</h2>' + 
                        '<div id="collapse_affectedItem_' + element.ShortName + '" class="accordion-collapse collapse" aria-labelledby="aria_'+ element.ShortName +'" data-bs-parent="#accordion_affectedItem_' + element.ShortName +'">' +
                          '<div class="accordion-body">'
      element.AffectedItems.forEach(item => {
        if(item['Id'] != null && item['Name'] != null){ 
          insertData = insertData + item['Id'] + " - " + item['Name'] + "</br>";
        }else{
          if(item['Id'] != null && item['Name'] == null){
            insertData = insertData + item['Id'] + "</br>";
          }else{
            if(item['Id'] == null && item['Name'] != null){
              insertData = insertData + item['Name'] + "</br>";
            }
          }
        }

      });
      insertData = insertData + "</div></div></div><br>"
      x = x.replace(/{{AffedtedItems}}/ig, insertData);
    }else{
      x = x.replace(/{{AffedtedItems}}/ig, "");
    }
      x = x.replace(/{{acordionSection}}/ig, accordionSection);
      x = x.replace(/{{collapseID}}/ig, "collapseAcordion_" + element.ShortName);
      return x;
};


  
  

function fillFindings(){
    
    $("#tenantid").html("Tenant ID: " + tenantData.TenantId);

    if(tenantData.Username.includes("@")){
        $("#userid").html("Username: " + tenantData.Username);
    }else{
        $("#userid").html("Application ID: " + tenantData.Username);
    }
    
    Chart.overrides.doughnut.plugins.legend.display = false;

    var m365_findings = [];
    var m365_nofindings = [];
    var m365_notApplicable = [];
    var m365_error = [];

    var azure_findings = [];
    var azure_nofindings = [];
    var azure_notApplicable = [];
    var azure_error = [];

    const accordionM365_Findings = "accordionM365_Findings";
    const accordionM365_NoFindings = "accordionM365_NoFindings";
    const accordionM365_NotApplicable = "accordionM365_NotApplicable";
    const accordionM365_Errors = "accordionM365_Errors";

    const accordionAzure_Findings = "accordionAzure_Findings";
    const accordionAzure_NoFindings = "accordionAzure_NoFindings";
    const accordionAzure_NotApplicable = "accordionAzure_NotApplicable"
    const accordionAzure_Errors = "accordionAzure_Errors";

    var m365_maxPoints = 0;
    var m365_achieved_points = 0;
    var m365_highest_risk = 0;

    var azure_maxPoints = 0;
    var azure_achieved_points = 0;
    var azure_highest_risk = 0;

    var temp = $.trim($('#AccordionTemplate').html());

    if(reportData.Finding != null){
        var data_sorted = reportData.Finding.sort((a1, a2) => (a1.RiskScore < a2.RiskScore) ? 1 : (a1.RiskScore > a2.RiskScore) ? -1 : 0); 
        data_sorted.forEach(element => {
          if(element.ShortDescription != null){
            if(element.Scope == "Azure"){
              azure_findings.push(createAccordionItem(element, accordionAzure_Findings));
              azure_maxPoints += element.RiskScore;
              azure_achieved_points += element.RiskScore;

              if(element.RiskScore > azure_highest_risk){
                azure_highest_risk = element.RiskScore;
              }
            }else{
              m365_findings.push(createAccordionItem(element, accordionM365_Findings));
              m365_maxPoints += element.RiskScore;
              m365_achieved_points += element.RiskScore;

              if(element.RiskScore > m365_highest_risk){
                m365_highest_risk = element.RiskScore;
              }
            }
          }
        });
        
        if(m365_findings.length > 0){
          var x = temp.replace(/{{Topic}}/ig, "Finding");
          x = x.replace(/{{ContainerID}}/ig, "M365_Finding_Container");
          x = x.replace(/{{accordionSection}}/ig, accordionM365_Findings);
          $('#M365-Mainview').append(x);       
          $('#' + accordionM365_Findings).append(m365_findings);
        }

        if(azure_findings.length > 0){
          var x = temp.replace(/{{Topic}}/ig, "Finding");
          x = x.replace(/{{ContainerID}}/ig, "Azure_Finding_Container");
          x = x.replace(/{{accordionSection}}/ig, accordionAzure_Findings);
          $('#Azure-Mainview').append(x); 
          $('#' + accordionAzure_Findings).append(azure_findings);
        }
    }

    if(reportData.NotApplicable != null){
      var data_sorted = reportData.NotApplicable.sort((a1, a2) => (a1.RiskScore < a2.RiskScore) ? 1 : (a1.RiskScore > a2.RiskScore) ? -1 : 0); 
      data_sorted.forEach(element => {
        if(element.ShortDescription != null){ 
          if(element.Scope == "Azure"){
            azure_notApplicable.push(createAccordionItem(element, accordionAzure_NotApplicable));
            azure_maxPoints += element.RiskScore;
          }else{
            m365_notApplicable.push(createAccordionItem(element, accordionM365_NotApplicable));
            m365_maxPoints += element.RiskScore;
          }
        }
      });

      if(m365_notApplicable.length > 0){
          var x = temp.replace(/{{Topic}}/ig, "Not Applicable");
          x = x.replace(/{{ContainerID}}/ig, "M365_NotApplicable_Container");
          x = x.replace(/{{accordionSection}}/ig, accordionM365_NotApplicable);
          $('#M365-Mainview').append(x);       
          $('#' + accordionM365_NotApplicable).append(m365_notApplicable);
      }

      if(azure_notApplicable.length > 0){
          var x = temp.replace(/{{Topic}}/ig, "Not Applicable");
          x = x.replace(/{{ContainerID}}/ig, "Azure_NotApplicable_Container");
          x = x.replace(/{{accordionSection}}/ig, accordionAzure_NotApplicable);
          $('#Azure-Mainview').append(x); 
          $('#' + accordionAzure_NotApplicable).append(azure_notApplicable);
      }
  };

    if(reportData.NoFinding != null){
        var data_sorted = reportData.NoFinding.sort((a1, a2) => (a1.RiskScore < a2.RiskScore) ? 1 : (a1.RiskScore > a2.RiskScore) ? -1 : 0); 
        data_sorted.forEach(element => {
          if(element.ShortDescription != null){
            if(element.Scope == "Azure"){
              azure_nofindings.push(createAccordionItem(element, accordionAzure_NoFindings));
              azure_maxPoints += element.RiskScore;
            }else{
              m365_nofindings.push(createAccordionItem(element, accordionM365_NoFindings));
              m365_maxPoints += element.RiskScore;
            }
          }
        });

        if(m365_nofindings.length > 0){
          var x = temp.replace(/{{Topic}}/ig, "No Finding");
          x = x.replace(/{{ContainerID}}/ig, "M365_NoFinding_Container");
          x = x.replace(/{{accordionSection}}/ig, accordionM365_NoFindings);
          $('#M365-Mainview').append(x);       
          $('#' + accordionM365_NoFindings).append(m365_nofindings);
        }

        if(azure_nofindings.length > 0){
          var x = temp.replace(/{{Topic}}/ig, "No Finding");
          x = x.replace(/{{ContainerID}}/ig, "Azure_NoFinding_Container");
          x = x.replace(/{{accordionSection}}/ig, accordionAzure_NoFindings);
          $('#Azure-Mainview').append(x); 
          $('#' + accordionAzure_NoFindings).append(azure_nofindings);
        }
    }

    if(reportData.Error != null){
        var data_sorted = reportData.Error.sort((a1, a2) => (a1.RiskScore < a2.RiskScore) ? 1 : (a1.RiskScore > a2.RiskScore) ? -1 : 0); 
        data_sorted.forEach(element => {
          if(element.ShortDescription != null){
            if(element.Scope == "Azure"){
                azure_error.push(createAccordionItem(element, accordionAzure_Errors));
            }else{
                m365_error.push(createAccordionItem(element, accordionM365_Errors));
            }
          }
        });

        if(m365_error.length > 0){
          var x = temp.replace(/{{Topic}}/ig, "Error");
          x = x.replace(/{{ContainerID}}/ig, "M365_Error_Container");
          x = x.replace(/{{accordionSection}}/ig, accordionM365_Errors);
          $('#M365-Mainview').append(x);       
          $('#' + accordionM365_Errors).append(m365_error);
        }

        if(azure_error.length > 0){
          var x = temp.replace(/{{Topic}}/ig, "Error");
          x = x.replace(/{{ContainerID}}/ig, "Azure_Error_Container");
          x = x.replace(/{{accordionSection}}/ig, accordionAzure_Errors);
          $('#Azure-Mainview').append(x); 
          $('#' + accordionAzure_Errors).append(azure_error);
        }
    };


    m365_risktext = "";
    m365_risk_chart_value = 0;
    if(m365_highest_risk == 0){
      m365_risktext = "Risklevel: None";
      m365_risk_chart_value = 0;
    }
    if(m365_highest_risk > 0 & m365_highest_risk <= 3){
      m365_risktext = "Risklevel: Low";
      m365_risk_chart_value = 0.5;
    }
    if(m365_highest_risk > 3 & m365_highest_risk <= 6){
      m365_risktext = "Risklevel: Medium";
      m365_risk_chart_value = 1.5;
    }
    if(m365_highest_risk > 6 & m365_highest_risk <= 9){
      m365_risktext = "Risklevel: High";
      m365_risk_chart_value = 2.5;
    }
    if(m365_highest_risk == 10){
      m365_risktext = "Risklevel: Ciritcal";
      m365_risk_chart_value = 3.5;
    }

    $("#m365_risk_level_label").html(m365_risktext);

    var m365_risk_chart_data = {
      value: m365_risk_chart_value,
      max: 4,
      label: "Risk"
    };

    var m365_risk_color = getColor(m365_risk_chart_value, 4);

    var m365_risk_chart_config = {
      type: 'doughnut',
      data: {
          labels: [m365_risk_chart_data.label],
          datasets: [{
              data: [m365_risk_chart_data.value, m365_risk_chart_data.max - m365_risk_chart_data.value],
              //backgroundColor: ['rgba(255, 0, 0, 1)', 'rgba(0, 0, 0, 0.1)'],
              backgroundColor: [m365_risk_color, 'rgba(0, 0, 0, 0.1)'],
              borderWidth: 0
          }]
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          cutoutPercentage: 85,
          rotation: -90,
          circumference: 180,
          tooltips: {
              enabled: false
          },
          legend: {
              display: false
          },
          animation: {
              animateRotate: true,
              animateScale: false
          },
          title: {
              display: false,
              text: m365_risk_chart_data.label,
              fontSize: 0
          }
      }
    };

  var ctx = document.getElementById('m365_risk_level_gaugechart').getContext('2d');
  new Chart(ctx, m365_risk_chart_config);

  var m365_points_text = "Points: " + m365_achieved_points + "/" + m365_maxPoints; 
  $("#m365_points_label").html(m365_points_text);

  var m365_points_chart_data = {
    value: m365_achieved_points,
    max: m365_maxPoints,
    label: "Points"
  };

  var m365_points_color = getColor(m365_achieved_points, m365_maxPoints);
  var m365_points_chart_config = {
    type: 'doughnut',
    data: {
        labels: [m365_points_chart_data.label],
        datasets: [{
            data: [m365_points_chart_data.value, m365_points_chart_data.max - m365_points_chart_data.value],
            backgroundColor: [m365_points_color, 'rgba(0, 0, 0, 0.1)'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutoutPercentage: 85,
        rotation: -90,
        circumference: 180,
        tooltips: {
            enabled: false
        },
        legend: {
            display: false
        },
        animation: {
            animateRotate: true,
            animateScale: false
        },
        title: {
            display: false,
            text: m365_points_chart_data.label,
            fontSize: 0
        }
    }
  };
  
  var ctx = document.getElementById('m365_points_gaugechart').getContext('2d');
  new Chart(ctx, m365_points_chart_config);


  azure_risktext = "";
  azure_risk_chart_value = 0;
  if(azure_highest_risk == 0){
    azure_risktext = "Risklevel: None";
    azure_risk_chart_value = 0;
  }
  if(azure_highest_risk > 0 & azure_highest_risk <= 3){
    azure_risktext = "Risklevel: Low";
    azure_risk_chart_value = 0.5;
  }
  if(azure_highest_risk > 3 & azure_highest_risk <= 6){
    azure_risktext = "Risklevel: Medium";
    azure_risk_chart_value = 1.5;
  }
  if(azure_highest_risk > 6 & azure_highest_risk <= 9){
    azure_risktext = "Risklevel: High";
    azure_risk_chart_value = 2.5;
  }
  if(azure_highest_risk == 10){
    azure_risktext = "Risklevel: Ciritcal";
    azure_risk_chart_value = 3.5;
  }

  $("#azure_risk_level_label").html(azure_risktext);
  
  var azure_risk_chart_data = {
    value: azure_risk_chart_value,
    max: 4,
    label: "Risk"
  };

  var azure_risk_color = getColor(azure_risk_chart_value, 4);

  var azure_risk_chart_config = {
    type: 'doughnut',
    data: {
        labels: [azure_risk_chart_data.label],
        datasets: [{
            data: [azure_risk_chart_data.value, azure_risk_chart_data.max - azure_risk_chart_data.value],
            //backgroundColor: ['rgba(255, 0, 0, 1)', 'rgba(0, 0, 0, 0.1)'],
            backgroundColor: [azure_risk_color, 'rgba(0, 0, 0, 0.1)'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutoutPercentage: 85,
        rotation: -90,
        circumference: 180,
        tooltips: {
            enabled: false
        },
        legend: {
            display: false
        },
        animation: {
            animateRotate: true,
            animateScale: false
        },
        title: {
            display: false,
            text: azure_risk_chart_data.label,
            fontSize: 0
        }
    }
  };

  var ctx = document.getElementById('azure_risk_level_gaugechart').getContext('2d');
  new Chart(ctx, azure_risk_chart_config);

  var azure_points_text = "Points: " + azure_achieved_points + "/" + azure_maxPoints; 
  $("#azure_points_label").html(azure_points_text);

  var azure_points_chart_data = {
    value: azure_achieved_points,
    max: azure_maxPoints,
    label: "Points"
  };

  var azure_points_color = getColor(azure_achieved_points, azure_maxPoints);
  var azure_points_chart_config = {
    type: 'doughnut',
    data: {
        labels: [azure_points_chart_data.label],
        datasets: [{
            data: [azure_points_chart_data.value, azure_points_chart_data.max - azure_points_chart_data.value],
            backgroundColor: [azure_points_color, 'rgba(0, 0, 0, 0.1)'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutoutPercentage: 85,
        rotation: -90,
        circumference: 180,
        tooltips: {
            enabled: false
        },
        legend: {
            display: false
        },
        animation: {
            animateRotate: true,
            animateScale: false
        },
        title: {
            display: false,
            text: azure_points_chart_data.label,
            fontSize: 0
        }
    }
  };

  var ctx = document.getElementById('azure_points_gaugechart').getContext('2d');
  new Chart(ctx, azure_points_chart_config);

  $("#M365_NoFinding_Container").hide();
  $("#Azure_NoFinding_Container").hide();

  $("#M365_Error_Container").hide();
  $("#Azure_Error_Container").hide();

  $("#loadingModal").modal('hide');

  $('#expertToggle').bootstrapToggle('enable')
  $('#expertToggle').change(function () {
    if($(this).prop('checked')){
      $("#M365_NoFinding_Container").show();
      $("#Azure_NoFinding_Container").show();

      $("#M365_Error_Container").show();
      $("#Azure_Error_Container").show();
    }else{
      $("#M365_NoFinding_Container").hide();
      $("#Azure_NoFinding_Container").hide();

      $("#M365_Error_Container").hide();
      $("#Azure_Error_Container").hide();
    }
  });
};


function fillDetails(){

  Object.entries(tenantData.Users).forEach(function([key, value]){
    //console.log(key + " " + value.userPrincipalName);
    $("#details_usertable > tbody").append(`<tr><td>${value.userPrincipalName}</td><td>${value.displayName}</td><td>${key}</td><td>${value.isMFAEnabled}</td></tr>`);

  });
  new DataTable('#details_usertable');
  
  Object.entries(tenantData.DirectoryRoles).forEach(function([key, value]){
    //console.log(key + " " + value.displayName);
    $("#details_rolestable > tbody").append(`<tr><td>${value.displayName}</td><td>${key}</td><td>${value.activeMembers.length}</td><td>${value.eligibleMembers.length}</td><td><button type="button" class="btn btn-primary" onclick="showRolesDetails('${key}')">Details</button></td></tr>`);

  });
  new DataTable('#details_rolestable');

  Object.entries(tenantData.Applications).forEach(function([key, value]){
    //console.log(key + " " + value.displayName);
    var passwordCredsSet = false;
    if(value.passwordCredentials.length > 0){
      passwordCredsSet = true;
    }
    var keyCredsSet = false;
    if(value.keyCredentials.length > 0){
      keyCredsSet = true;
    }
    $("#details_appregtable > tbody").append(`<tr><td>${value.displayName}</td><td>${key}</td><td>${value.owners.length}</td><td>${passwordCredsSet}</td><td>${keyCredsSet}</td><td>${value.UserAbleToAddCreds.length}</td></tr>`);

  });
  new DataTable('#details_appregtable');

  Object.entries(tenantData.ServicePrincipals).forEach(function([key, value]){
    //console.log(key + " " + value.displayName);
    var userConsentArray = [];
    var userConsent = "";
    var adminConsentArray = [];
    var adminConsent = "";
 

    if(value.oauth2PermissionGrants != null){
      value.oauth2PermissionGrants.forEach(function(item, key){
        if(item.consentType == "AllPrincipals"){
          if(jQuery.inArray(item.scope, adminConsentArray) == -1){
            adminConsentArray.push(item.scope);
            adminConsent = adminConsent + item.scope + "<br>"
          }
        }else{
          if(jQuery.inArray(item.scope, userConsentArray) == -1){
            userConsentArray.push(item.scope);
            userConsent = userConsent + item.scope + "<br>"
          }
        }
      });
    }

    var appRoles = "";
    if(value.appRoleAssignments != null){
      
      value.appRoleAssignments.forEach(function(item, key){
        appRoles = appRoles + appRoleIDtoNameAndResource(item.appRoleId, item.resourceId) + "<br>";
      });
    }

    $("#details_servicetable > tbody").append(`<tr><td>${value.appDisplayName}</td><td>${key}</td><td>${value.appOwnerOrganizationId}</td><td>${userConsent}</td><td>${adminConsent}</td><td>${appRoles}</td></tr>`);

  });
  //var serviceTable = new DataTable('#details_servicetable');
  $("#details_servicetable").dataTable({
    "columns": [
      { "width": "20%" },
      { "width": "10%" },
      { "width": "10%" },
      { "width": "20%" },
      { "width": "20%" },
      { "width": "20%" }
    ]
  })

};

function appRoleIDtoNameAndResource(appRoleId, resourceId){

  var servicePrincipal = tenantData.ServicePrincipals[resourceId];
  var returnValue = "";
  servicePrincipal.appRoles.forEach(function(item, key){
    if(item.id == appRoleId){
      returnValue = `[${servicePrincipal.appDisplayName}]::${item.value}`;
    }
  });

  if(returnValue == ""){
    return "Unknown";
  }else{
    return returnValue;
  }
};

function createRoleDetailTableArray(members){
  var result = [];
  members.forEach(member =>{
    var displayname = "";
    var upn = "";
    var objectid = "";
    var principal = tenantData.Users[member.id];
    if(principal != undefined){
      displayname = principal.displayName;
      upn = principal.userPrincipalName;
      objectid = principal.id;
    }

    if( principal == undefined ){
      principal = tenantData.Guests[member.id];
      if(principal != undefined){
        displayname = principal.displayName;
        upn = principal.userPrincipalName;
        objectid = principal.id;
      }
    }
    if(principal == undefined){
      principal = tenantData.ServicePrincipals[member.id];
      if(principal != undefined){
        displayname = principal.appDisplayName;
        objectid = principal.appId;
      }
    }
    
    if( principal != undefined ){
      var memberData = [
        displayname,
        upn,
        objectid
      ]
      result.push(memberData);
    }
  });
  return result;
}

function showRolesDetails(id){
  //alert("Show Details " + id);
  var tableActiveMember = new DataTable('#RolesDetailsTableAssignedUser');
  tableActiveMember.clear();

  var tableEligibleMember = new DataTable('#RolesDetailsTableEliglibeUser');
  tableEligibleMember.clear();


  var role = tenantData.DirectoryRoles[id];
  var activeMembers = role.activeMembers;
  var eligibleMembers = role.eligibleMembers;

  var activeMemberData = createRoleDetailTableArray(activeMembers);
  var eligibleMemberData  = createRoleDetailTableArray(eligibleMembers);

  tableActiveMember.rows.add(activeMemberData);
  tableActiveMember.draw();

  tableEligibleMember.rows.add(eligibleMemberData);
  tableEligibleMember.draw();

  $('#RolesDetailModalLabel').html(`Details: ${role.displayName}`);

  $('#RolesDetailModal').modal('show');

}

function initData(){
  new DataTable('#RolesDetailsTableAssignedUser');
}
 